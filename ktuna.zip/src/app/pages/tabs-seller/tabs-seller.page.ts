import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabs-seller',
  templateUrl: './tabs-seller.page.html',
  styleUrls: ['./tabs-seller.page.scss'],
})
export class TabsSellerPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
