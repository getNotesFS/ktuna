import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-in-client',
  templateUrl: './sign-in-client.page.html',
  styleUrls: ['./sign-in-client.page.scss'],
})
export class SignInClientPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
